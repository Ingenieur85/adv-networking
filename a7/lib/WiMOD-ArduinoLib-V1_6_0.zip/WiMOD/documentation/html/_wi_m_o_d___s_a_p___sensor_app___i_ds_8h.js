var _wi_m_o_d___s_a_p___sensor_app___i_ds_8h =
[
    [ "TWiMODLR_SensorApp_Config", "struct_t_wi_m_o_d_l_r___sensor_app___config.html", "struct_t_wi_m_o_d_l_r___sensor_app___config" ],
    [ "TWiMODLR_SensorApp_SensorData", "struct_t_wi_m_o_d_l_r___sensor_app___sensor_data.html", "struct_t_wi_m_o_d_l_r___sensor_app___sensor_data" ],
    [ "TWiMODLR_SensorApp_AckSensorData", "struct_t_wi_m_o_d_l_r___sensor_app___ack_sensor_data.html", "struct_t_wi_m_o_d_l_r___sensor_app___ack_sensor_data" ],
    [ "SENSORAPP_ANALOG_INPUT_ONE_SET", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#ae3ebd19abdea17cf7eeea406913f58bb", null ],
    [ "SENSORAPP_DIGITAL_INPUT_ONE_SET", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#acfed8deb9a3bd584f98e80f8306a87b0", null ],
    [ "SENSORAPP_DIGITAL_INPUT_THREE_SET", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a13aa6f561af50d07dbb825a2db90c151", null ],
    [ "SENSORAPP_DIGITAL_INPUT_TWO_SET", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a5dd3170037d47624d040ec4b3c96426e", null ],
    [ "SENSORAPP_FORMAT_EXT_HCI_OUT_ACTIVE", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#ad8cf666bb56b652145453a200c2757b9", null ],
    [ "SENSORAPP_OPTION_ACK_MSG_HCI_OUTPUT", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a01877d2da4589ca2b4f9a2b5cfd30c67", null ],
    [ "SENSORAPP_OPTION_LINK_MON_SIGNAL_OUTPUT", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#aa5a787963b332b64bb7e65ba835ec24d", null ],
    [ "SENSORAPP_OPTION_PUSH_BUTTON_ONE", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a9735182b37f00ecbe2a1bd6dcf882407", null ],
    [ "SENSORAPP_OPTION_SENSOR_ACK_MSG", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#aad8c900b3e69656c6e16e8fb0e834660", null ],
    [ "SENSORAPP_SAP_ID", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a2bef5883c7c5db4b8a6670142cb7635a", null ],
    [ "SENSORAPP_STATUS_ERROR", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#af1f8cbe8a855aebe138838b19682de16", null ],
    [ "SENSORAPP_STATUS_OK", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a6db73ddc53c0c2252baebdf4b8a13501", null ],
    [ "SENSORAPP_STATUS_WRONG_DEVICEMODE", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a7d8a1809659a645626538e1187e0d78a", null ],
    [ "TSensorApp_Mode", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#adb50ba19708b3a0c34b121dbf7abe91c", null ],
    [ "TWiMODLR_SensorApp_AckSensorData", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#af94138db41f73a163f1a6efbd275dab3", null ],
    [ "TWiMODLR_SensorApp_Config", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#af7260885f12e07789eb8dd2ef74c8534", null ],
    [ "TWiMODLR_SensorApp_SensorData", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a6786cb0e4ddba1088aab4ba0f2608b35", null ],
    [ "TSensorApp_Mode", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a49817714374ebcf022b82b6239583859", [
      [ "SensorApp_Mode_Off", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a49817714374ebcf022b82b6239583859ac1a0d03c3d09ac0d89cf32dfbb95b0a2", null ],
      [ "SensorApp_Mode_SensorDataTransmitter", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a49817714374ebcf022b82b6239583859a25e4df1c46206817ea862461981f4cce", null ],
      [ "SensorApp_Mode_SensorDataReceiver", "_wi_m_o_d___s_a_p___sensor_app___i_ds_8h.html#a49817714374ebcf022b82b6239583859a18ae7a858c928cc6665a0f73c52db3fe", null ]
    ] ]
];