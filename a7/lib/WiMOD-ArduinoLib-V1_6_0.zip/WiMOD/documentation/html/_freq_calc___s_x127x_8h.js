var _freq_calc___s_x127x_8h =
[
    [ "FreqCalc_calcFreqToRegister", "_freq_calc___s_x127x_8h.html#ac2bd61c2183d22dbcf5f95bda2676e62", null ],
    [ "FreqCalc_calcRegisterToFreq", "_freq_calc___s_x127x_8h.html#a9f3a82537c81953e60c700d2b7a27bfb", null ]
];