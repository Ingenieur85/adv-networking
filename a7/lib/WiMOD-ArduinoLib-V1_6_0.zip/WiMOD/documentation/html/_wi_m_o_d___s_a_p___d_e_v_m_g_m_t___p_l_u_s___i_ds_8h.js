var _wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h =
[
    [ "TWiMODLR_DevMgmt_RadioConfigPlus", "struct_t_wi_m_o_d_l_r___dev_mgmt___radio_config_plus.html", "struct_t_wi_m_o_d_l_r___dev_mgmt___radio_config_plus" ],
    [ "TWiMODLR_DevMgmt_SystemStatusPlus", "struct_t_wi_m_o_d_l_r___dev_mgmt___system_status_plus.html", "struct_t_wi_m_o_d_l_r___dev_mgmt___system_status_plus" ],
    [ "TRadioCfg_FLRCBandwidthPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a67cbba6667c9276e9a32f0c1ec66677a", null ],
    [ "TRadioCfg_FLRCErrorCodingPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a91fa4c6a6d0addc7039bd3e4f8ef6d18", null ],
    [ "TRadioCfg_FSKBandwidthPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a666679ffbc1789ad206b4891490fcf71", null ],
    [ "TRadioCfg_LoRaBandwidthPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a048654fded375ec5b2110452fc6914f7", null ],
    [ "TRadioCfg_LoRaErrorCodingPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a91aab2410dac7095dd9cb52f41364177", null ],
    [ "TRadioCfg_LoRaSpreadingFactorPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#aadbf1ac3c6d2df9563d5b14c944bee06", null ],
    [ "TRadioCfg_ModulationPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a1e486ac08652876a367ae4e7b98dabac", null ],
    [ "TRadioCfg_PowerLevelPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a0d7164211c32d19c4f27309d50f86500", null ],
    [ "TRadioCfg_PowerSavingModePlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ad7886eea8656ea45f2f2c1e51aefed6a", null ],
    [ "TRadioCfg_RadioModePlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a7cdcf290334c2c6466858164859248e6", null ],
    [ "TRadioCfg_RxControlPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a081e63ccbf9d68265418001cab413edb", null ],
    [ "TRadioCfg_TxControlPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a14285222a2a00044b6357adc8de23168", null ],
    [ "TWiMODLR_DevMgmt_RadioConfigPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a2a96979482413bc07f1d707fbb77de0f", null ],
    [ "TWiMODLR_DevMgmt_SystemStatusPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a16eb5573826f6a2f45e9cff9c334cbd6", null ],
    [ "TRadioCdf_TxPowerLevelPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6", [
      [ "LRBASE_PLUS_TxPowerLevel_m18_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6af03b0ead27196ce2d3ba62cf69ed988e", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m17_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6ac1e83808fae6f732b0ff9beb954843e2", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m16_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a7f394e0ae5c56a126c6cd5e827a15b12", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m15_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a5aadacc264c30a5e70b839904471abb7", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m14_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6af47bc4fcc52eecc42e752eaea225bcb0", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m13_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6ac2720e00dd146a7ce80fbc2f133ba283", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m12_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6afe5a45c10f4539a3075f1e5eb6e316a4", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m11_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6aec1cfde8e99e85200b6dc1c54f9e3101", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m10_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a2f8a357ade4fdb57d90455abcc41d8c8", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m09_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a7ebf91a2d9f5fa56768f95994ffcf19c", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m08_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a98d9f10f0a1ac6f75b872a6da9958a5b", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m07_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a4b90bcafbfde8507568a9079c48fec10", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m06_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6ac8d42c92100b4a1808be196c7daf6b48", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m05_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a02f6d605cdbdb56909fd4a32f500c9c1", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m04_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a522d8e553199332a28a82db292d233af", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m03_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a35b629594717e50a4c42b3cc9a95f679", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m02_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6ad9107508654e9aaaba62e6160aff7310", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m01_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a0a0a5053ecd3dee3ded1213c73da06d6", null ],
      [ "LRBASE_PLUS_TxPowerLevel_m00_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a4d4ca10dc22782eae8f87ba82ae9d2a8", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p01_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6aee9e9d72c64cff9cdc316bd9dc36e311", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p02_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a0c8c765f1bd3a4561749099488f4e579", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p03_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a9b2608497bf32e861301529aaae95524", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p04_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a347354101f626a2e3b4aa346632f1247", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p05_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a5cb85d143a7d0f1710dee6c2ffee4330", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p06_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a16a9efedd84a6cf2f783aed7517e7389", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p07_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6aac371b7c3660a00e3fe777bede240e1d", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p08_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a22aa7a2a812ea50035c50f849873c80b", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p09_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6aeca67851801545fd7b6e77ee90394f9f", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p10_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a76292c6184f7b493d3a2d07eaa0259a5", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p11_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6ae961b336220a0d3155e0db6f5a71d24a", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p12_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a5a5fb037771332919a13aab53df02a65", null ],
      [ "LRBASE_PLUS_TxPowerLevel_p13_dBm", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae1ccc693b859d15c11975a5b5e1405d6a62acc40213686b1efb6cd3f20fb63dbf", null ]
    ] ],
    [ "TRadioCfg_FLRCBandwidthPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#abe6a16e071d2d1379915bc4ca3584339", [
      [ "LRBASE_PLUS_FLRCBandwith_0_260MBs_0_3_MHz_DSB", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#abe6a16e071d2d1379915bc4ca3584339af7a86e694571e2174a35add2c719166b", null ],
      [ "LRBASE_PLUS_FLRCBandwith_0_325MBs_0_3_MHz_DSB", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#abe6a16e071d2d1379915bc4ca3584339a83b7f113db936f5861f3a9b1955fad0c", null ],
      [ "LRBASE_PLUS_FLRCBandwith_0_520MBs_0_6_MHz_DSB", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#abe6a16e071d2d1379915bc4ca3584339a1e2d59101909e44356b2b4a735a07c56", null ],
      [ "LRBASE_PLUS_FLRCBandwith_0_650MBs_0_6_MHz_DSB", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#abe6a16e071d2d1379915bc4ca3584339a6f5ff4c95dbae1721940c12a860bc79d", null ],
      [ "LRBASE_PLUS_FLRCBandwith_1_040MBs_1_2_MHz_DSB", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#abe6a16e071d2d1379915bc4ca3584339ae26e5457f5ce227e72884084bc566a99", null ],
      [ "LRBASE_PLUS_FLRCBandwith_1_300MBs_1_2_MHz_DSB", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#abe6a16e071d2d1379915bc4ca3584339a0dd51c67eef4d4447889e66c95376873", null ]
    ] ],
    [ "TRadioCfg_FLRCErrorCodingPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#adfa1d656ed877c5b7d3cf3aa13f83bf1", [
      [ "LRBASE_PLUS_FLRC_ErrorCoding_1_2", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#adfa1d656ed877c5b7d3cf3aa13f83bf1a463fc86e143b420d7987a6e941bec5ff", null ],
      [ "LRBASE_PLUS_FLRC_ErrorCoding_3_4", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#adfa1d656ed877c5b7d3cf3aa13f83bf1a2c34eb200d39dcd8a94075c25e64034a", null ],
      [ "LRBASE_PLUS_FLRC_ErrorCoding_1_1", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#adfa1d656ed877c5b7d3cf3aa13f83bf1a04d625d4718b87fe999f9cd88b3533d0", null ]
    ] ],
    [ "TRadioCfg_FSKBandwidthPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a482896b56d205cb77f6f1a0f418ec450", [
      [ "LRBASE_PLUS_FSKBandwith_2_0MBs_2_4_MHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a482896b56d205cb77f6f1a0f418ec450a2f2ee94e6c8106748d7ed8eb19d87d7e", null ],
      [ "LRBASE_PLUS_FSKBandwith_1_0MBs_1_2_MHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a482896b56d205cb77f6f1a0f418ec450a82a78b73b2fb93a5cc48dbcf350fcbff", null ],
      [ "LRBASE_PLUS_FSKBandwith_0_250MBs_0_3_MHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a482896b56d205cb77f6f1a0f418ec450a5ea18405af2ebe5accbc89dfbaa77874", null ],
      [ "LRBASE_PLUS_FSKBandwith_0_125MBs_0_3_MHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a482896b56d205cb77f6f1a0f418ec450ab3a96475c2a544cd222f495a50b791f4", null ]
    ] ],
    [ "TRadioCfg_LoRaBandwidthPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a11a8635da4f1ce63bf140266a5f6d9d0", [
      [ "LRBASE_PLUS_LoRaBandwith_200kHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a11a8635da4f1ce63bf140266a5f6d9d0a46e46926e078ce59c8bc1f03113509a4", null ],
      [ "LRBASE_PLUS_LoRaBandwith_400kHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a11a8635da4f1ce63bf140266a5f6d9d0a0ef7e1ff7101c8fd2abd3bed9de2f91d", null ],
      [ "LRBASE_PLUS_LoRaBandwith_800kHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a11a8635da4f1ce63bf140266a5f6d9d0abecdd21e9bd1508d55699489b5df9a9b", null ],
      [ "LRBASE_PLUS_LoRaBandwith_1600kHz", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a11a8635da4f1ce63bf140266a5f6d9d0a60678bba5ffbe94e777d6ec62b214750", null ]
    ] ],
    [ "TRadioCfg_LoRaErrorCodingPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#aa882ae990192c82aa979d4067ed3af5b", [
      [ "LRBASE_PLUS_LoRa_ErrorCoding_4_5", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#aa882ae990192c82aa979d4067ed3af5ba6f0c02120ce22cd80504608aec7b9679", null ],
      [ "LRBASE_PLUS_LoRa_ErrorCoding_4_6", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#aa882ae990192c82aa979d4067ed3af5ba84964a5e1d01dfc31e3294147ee1fa2f", null ],
      [ "LRBASE_PLUS_LoRa_ErrorCoding_4_7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#aa882ae990192c82aa979d4067ed3af5badf0e853f4f662f08de39bc76394277cb", null ],
      [ "LRBASE_PLUS_LoRa_ErrorCoding_4_8", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#aa882ae990192c82aa979d4067ed3af5bac3c2bdf57c4f1ad56ccf51303344d3d9", null ],
      [ "LRBASE_PLUS_LoRa_ErrorCoding_LI_4_5", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#aa882ae990192c82aa979d4067ed3af5bacc4ab5c4da72d343e97f4dd372c3622a", null ],
      [ "LRBASE_PLUS_LoRa_ErrorCoding_LI_4_6", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#aa882ae990192c82aa979d4067ed3af5badab834b88b0bb7667a3664d38ecc6272", null ],
      [ "LRBASE_PLUS_LoRa_ErrorCoding_LI_4_8", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#aa882ae990192c82aa979d4067ed3af5ba9e0e692a1feba02103338613d6c41378", null ]
    ] ],
    [ "TRadioCfg_LoRaSpreadingFactorPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a50bb798eebb0e01733386eb3fcdd3bb3", [
      [ "LRBASE_PLUS_LoRa_SF5", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a50bb798eebb0e01733386eb3fcdd3bb3a99a22769171d7381a78241b10fb2ed21", null ],
      [ "LRBASE_PLUS_LoRa_SF6", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a50bb798eebb0e01733386eb3fcdd3bb3aa67a862a762303cd3cbc81772f89d4df", null ],
      [ "LRBASE_PLUS_LoRa_SF7", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a50bb798eebb0e01733386eb3fcdd3bb3a6cd9145f75dd61d4e041006e114a0d94", null ],
      [ "LRBASE_PLUS_LoRa_SF8", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a50bb798eebb0e01733386eb3fcdd3bb3a21c197a2def2b5b6c0a812b526c82379", null ],
      [ "LRBASE_PLUS_LoRa_SF9", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a50bb798eebb0e01733386eb3fcdd3bb3a31b17356a744d443b4c6878ba0b0c1c1", null ],
      [ "LRBASE_PLUS_LoRa_SF10", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a50bb798eebb0e01733386eb3fcdd3bb3a45b6b726d9711fd1bfc00301e4b1c3fc", null ],
      [ "LRBASE_PLUS_LoRa_SF11", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a50bb798eebb0e01733386eb3fcdd3bb3a86c68dbf9eb43e547f2e0f08789fad14", null ],
      [ "LRBASE_PLUS_LoRa_SF12", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a50bb798eebb0e01733386eb3fcdd3bb3a1a55d76e3a7819f4b4681fbafa49c0e1", null ]
    ] ],
    [ "TRadioCfg_ModulationPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a8bc8cf3e70f4a8eae3404e364f686706", [
      [ "LRBASE_PLUS_Modulation_LoRa", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a8bc8cf3e70f4a8eae3404e364f686706a923fb91222c30c3d9eeaab7dab044b98", null ],
      [ "LRBASE_PLUS_Modulation_FLRC", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a8bc8cf3e70f4a8eae3404e364f686706a2d5deb63dc3de4ae71e749cd56579ab9", null ],
      [ "LRBASE_PLUS_Modulation_FSK", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a8bc8cf3e70f4a8eae3404e364f686706a374ca58a1e3d248f9e0a8efe23220ba4", null ]
    ] ],
    [ "TRadioCfg_PowerSavingModePlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a32af27f28770fcfe021b93b6818ab43b", [
      [ "LRBASE_PLUS_PowerSaving_Off", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a32af27f28770fcfe021b93b6818ab43ba168ddb9391b660b57410c2c408044254", null ],
      [ "LRBASE_PLUS_PowerSaving_On", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#a32af27f28770fcfe021b93b6818ab43ba7e8f118f35cd71ddeac7d557e55d1e5e", null ]
    ] ],
    [ "TRadioCfg_RadioModePlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae2c1bc5294eabc362701b81939a01506", [
      [ "LRBASE_PLUS_RadioMode_Standard", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae2c1bc5294eabc362701b81939a01506abd8b482d00f77524e345c97983543a49", null ],
      [ "LRBASE_PLUS_RadioMode_Reserved", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae2c1bc5294eabc362701b81939a01506a1e0d777d3b7f3991a880fd43978ebff8", null ],
      [ "LRBASE_PLUS_RadioMode_Sniffer", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ae2c1bc5294eabc362701b81939a01506ab538376b73de4367a2f307b9d2fffa5b", null ]
    ] ],
    [ "TRadioCfg_RxControlPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ade1f773a08559790f78a8422ecbf525a", [
      [ "LRBASE_PLUS_RxCtrl_Receiver_Off", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ade1f773a08559790f78a8422ecbf525aa5586b9d8bdddbab7f98dd74a3d56e93e", null ],
      [ "LRBASE_PLUS_RxCtrl_Receiver_AlwaysOn", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ade1f773a08559790f78a8422ecbf525aa8077441265a680f4b6d46c9fb349edbb", null ],
      [ "LRBASE_PLUS_RxCtrl_Receiver_RxWindowed", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ade1f773a08559790f78a8422ecbf525aa25e328d9dec15e8a7b07919c5f286a9b", null ]
    ] ],
    [ "TRadioCfg_TxControlPlus", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ab0679384a43a7a77afacebbc64f8c601", [
      [ "LRBASE_PLUS_TxCtrl_LBT_Off", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ab0679384a43a7a77afacebbc64f8c601ab5fdd8c38acd9e354a310f9b79e4a58e", null ],
      [ "LRBASE_PLUS_TxCtrl_LBT_On", "_wi_m_o_d___s_a_p___d_e_v_m_g_m_t___p_l_u_s___i_ds_8h.html#ab0679384a43a7a77afacebbc64f8c601a298a4c37ac05f804c0c31f882f27e34f", null ]
    ] ]
];