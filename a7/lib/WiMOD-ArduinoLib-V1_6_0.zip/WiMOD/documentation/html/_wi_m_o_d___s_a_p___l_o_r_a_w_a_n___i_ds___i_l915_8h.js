var _wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h =
[
    [ "TLoRaWAN_Channel_IL", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#aef5c4504afe8d2e4752f86e7439ff24d", null ],
    [ "TLoRaWANDataRateIL915", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#abf6fd1594c71455475df2ff25409982e", null ],
    [ "TLoRaWAN_Channel_IL", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a57d9c833f122f57b1e0058d4dfc45516", [
      [ "LoRaWAN_Channel_IL_915_7_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a57d9c833f122f57b1e0058d4dfc45516a5580115c0ed72cc2efc2f67e8e51c380", null ],
      [ "LoRaWAN_Channel_IL_915_9_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a57d9c833f122f57b1e0058d4dfc45516a49d461842c4ac6104e530844afef4081", null ],
      [ "LoRaWAN_Channel_IL_916_1_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a57d9c833f122f57b1e0058d4dfc45516ada8c66898bb2aa5e504af1bcdef5598e", null ],
      [ "LoRaWAN_Channel_IL_916_3_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a57d9c833f122f57b1e0058d4dfc45516a692e1f2d5a48b481234df632d9c255f4", null ]
    ] ],
    [ "TLoRaWANDataRateIL915", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a0c066d0a8c108f4850b0027115f13d87", [
      [ "LoRaWAN_DataRate_IL915_LoRa_SF12_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a0c066d0a8c108f4850b0027115f13d87ac5bdbd0e08f56f0997f6cf5efec0b90d", null ],
      [ "LoRaWAN_DataRate_IL915_LoRa_SF11_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a0c066d0a8c108f4850b0027115f13d87a799ebeebd7efbaf926fcee49b901505f", null ],
      [ "LoRaWAN_DataRate_IL915_LoRa_SF10_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a0c066d0a8c108f4850b0027115f13d87a36e82ec9c318e4eb8ee5068c68f167b2", null ],
      [ "LoRaWAN_DataRate_IL915_LoRa_SF9_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a0c066d0a8c108f4850b0027115f13d87aecd7cce6b32ea7daf8c3217ed62ac5a7", null ],
      [ "LoRaWAN_DataRate_IL915_LoRa_SF8_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a0c066d0a8c108f4850b0027115f13d87a7609d8f5744437ac88b7546b4285cd0d", null ],
      [ "LoRaWAN_DataRate_IL915_LoRa_SF7_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a0c066d0a8c108f4850b0027115f13d87ae4384bffbbbc8264a6ecca3eeec25581", null ],
      [ "LoRaWAN_DataRate_IL915_LoRa_SF7_250kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a0c066d0a8c108f4850b0027115f13d87a5a401405a61065eddce6dfe12b5e2184", null ],
      [ "LoRaWAN_DataRate_IL915_LoRa_FSK", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___i_l915_8h.html#a0c066d0a8c108f4850b0027115f13d87ae63f08995288cce2f756e7292f2bf725", null ]
    ] ]
];