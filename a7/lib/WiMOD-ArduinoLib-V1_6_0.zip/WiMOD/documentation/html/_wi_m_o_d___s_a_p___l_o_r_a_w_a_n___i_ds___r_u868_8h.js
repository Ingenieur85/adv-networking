var _wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h =
[
    [ "TLoRaWAN_Channel_RussiaFive", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#afad178fd85e9b50950a23cd65cb1f2ad", null ],
    [ "TLoRaWAN_Channel_RussiaFour", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a29cd387b7e655939b9b218133ae79272", null ],
    [ "TLoRaWAN_Channel_RussiaOne", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#abb6202d92346473ec22b029c0fe949d1", null ],
    [ "TLoRaWAN_Channel_RussiaSeven", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a9b210ce5db639e1982a22a7925fab44d", null ],
    [ "TLoRaWAN_Channel_RussiaSix", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a602e2ed043642b757e9de43a464ed43f", null ],
    [ "TLoRaWAN_Channel_RussiaThree", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a07b5f98c59eaba0c356dfef01be7aa47", null ],
    [ "TLoRaWAN_Channel_RussiaTwo", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#adb59f0bdebc27f3d4639158a7c92e577", null ],
    [ "TLoRaWANDataRateRU868", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#ae8898ca45ba131c6a2fa9e4c7d7829bc", null ],
    [ "TLoRaWAN_Channel_RussiaFive", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#aa6c0928d979f7f2dc30a944a3bb8e818", [
      [ "LoRaWAN_Channel_Russia5_864_5_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#aa6c0928d979f7f2dc30a944a3bb8e818a202d3fe316327f2b400bd00a5b4d0fb6", null ],
      [ "LoRaWAN_Channel_Russia5_864_7_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#aa6c0928d979f7f2dc30a944a3bb8e818ae9528ca84635f3a40e3c42d1eb331c90", null ],
      [ "LoRaWAN_Channel_Russia5_864_9_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#aa6c0928d979f7f2dc30a944a3bb8e818a6f688ea6860220d54e9b99f6096be9ab", null ],
      [ "LoRaWAN_Channel_Russia5_864_1_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#aa6c0928d979f7f2dc30a944a3bb8e818ace9649f6775d2a6897b5216e8b23f6dd", null ],
      [ "LoRaWAN_Channel_Russia5_864_3_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#aa6c0928d979f7f2dc30a944a3bb8e818ac6d4042d74b272e39db5359484e3f909", null ],
      [ "LoRaWAN_Channel_Russia5_868_8_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#aa6c0928d979f7f2dc30a944a3bb8e818af14c0fac1ffac8e174e811b95d611d19", null ],
      [ "LoRaWAN_Channel_Russia5_869_05_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#aa6c0928d979f7f2dc30a944a3bb8e818afbe53cedc2111f378df6101fb334cf2c", null ]
    ] ],
    [ "TLoRaWAN_Channel_RussiaFour", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#af4744c6cbeac459c7446a5c169cc47ed", [
      [ "LoRaWAN_Channel_Russia4_864_1_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#af4744c6cbeac459c7446a5c169cc47eda5aaaaec0282a1daf981244d732e4b0cd", null ],
      [ "LoRaWAN_Channel_Russia4_864_3_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#af4744c6cbeac459c7446a5c169cc47edabb9fbf0e1145cb1948dbf3dd55baff74", null ],
      [ "LoRaWAN_Channel_Russia4_869_5_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#af4744c6cbeac459c7446a5c169cc47edab8247433d1e6fb4325ffd2551eb27f0b", null ],
      [ "LoRaWAN_Channel_Russia4_864_64_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#af4744c6cbeac459c7446a5c169cc47eda44028b31b59c1549a26b714ca43af62b", null ],
      [ "LoRaWAN_Channel_Russia4_864_78_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#af4744c6cbeac459c7446a5c169cc47eda72aa9b1914594fbc8e6b333d5b4066bf", null ],
      [ "LoRaWAN_Channel_Russia4_868_78_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#af4744c6cbeac459c7446a5c169cc47eda5f1ee4673b85ca06d009d700e0aeae5a", null ],
      [ "LoRaWAN_Channel_Russia4_868_95_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#af4744c6cbeac459c7446a5c169cc47edae6d11b14afd06e5a6edb3ac0892ddc14", null ],
      [ "LoRaWAN_Channel_Russia4_869_12_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#af4744c6cbeac459c7446a5c169cc47eda3387ec6d83a354e918a94f0cf75c487f", null ],
      [ "LoRaWAN_Channel_Russia4_864_92_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#af4744c6cbeac459c7446a5c169cc47edaf4993b26a70993cbee1deef580e5cb80", null ]
    ] ],
    [ "TLoRaWAN_Channel_RussiaOne", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a94f2786fa36c2fe55ff451c2010d8a9e", [
      [ "LoRaWAN_Channel_Russia1_868_78_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a94f2786fa36c2fe55ff451c2010d8a9eac01aa14124825aaaf5cced78263969a5", null ],
      [ "LoRaWAN_Channel_Russia1_868_95_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a94f2786fa36c2fe55ff451c2010d8a9ea5a9389fac03e6b95a3dc35113c19a3c2", null ],
      [ "LoRaWAN_Channel_Russia1_869_12_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a94f2786fa36c2fe55ff451c2010d8a9eaffcb8c37dfa8ea721bddafeda436c0e4", null ],
      [ "LoRaWAN_Channel_Russia1_864_1_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a94f2786fa36c2fe55ff451c2010d8a9ea0a6f0effdeaa2e8d5002f24b5cc598af", null ],
      [ "LoRaWAN_Channel_Russia1_864_3_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a94f2786fa36c2fe55ff451c2010d8a9ea649a88a5491d377c10301c710c84e79d", null ],
      [ "LoRaWAN_Channel_Russia1_864_5_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a94f2786fa36c2fe55ff451c2010d8a9ea8a363d2efcb041142475851ca24b9a7f", null ],
      [ "LoRaWAN_Channel_Russia1_864_7_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a94f2786fa36c2fe55ff451c2010d8a9ea30545a61568da63e651297a34f3e28b1", null ],
      [ "LoRaWAN_Channel_Russia1_864_9_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a94f2786fa36c2fe55ff451c2010d8a9ea3e5cfa35c0f8eaca2c7536c749cf74a1", null ]
    ] ],
    [ "TLoRaWAN_Channel_RussiaSeven", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a938b2fa4c2a68a35c6b48489f09d9afa", [
      [ "LoRaWAN_Channel_Russia7_868_9_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a938b2fa4c2a68a35c6b48489f09d9afaac18f010c71e266fd667e351186b48e61", null ],
      [ "LoRaWAN_Channel_Russia7_869_1_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a938b2fa4c2a68a35c6b48489f09d9afaafad9885d3df0592da09f7301d0bee25c", null ],
      [ "LoRaWAN_Channel_Russia7_869_1_Mhz_2", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a938b2fa4c2a68a35c6b48489f09d9afaa7af81cc7b0ccea997a54c2ce3182ca42", null ]
    ] ],
    [ "TLoRaWAN_Channel_RussiaSix", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a1e4fabf79c66822c916919e19af2360e", [
      [ "LoRaWAN_Channel_Russia6_868_9_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a1e4fabf79c66822c916919e19af2360eaf673a0e3eaa525809cf834a5be45d1e2", null ],
      [ "LoRaWAN_Channel_Russia6_869_1_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a1e4fabf79c66822c916919e19af2360ead9df13e4c1c4d5549e99359219509ddd", null ],
      [ "LoRaWAN_Channel_Russia6_864_1_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a1e4fabf79c66822c916919e19af2360ea9ede6e576cd63ae0907f28995c5728c8", null ],
      [ "LoRaWAN_Channel_Russia6_864_3_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a1e4fabf79c66822c916919e19af2360ea5e85eeba1038a52354d847c73d49600c", null ],
      [ "LoRaWAN_Channel_Russia6_864_5_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a1e4fabf79c66822c916919e19af2360eaa5b6203fc1cd76fb9c7f6de871836055", null ],
      [ "LoRaWAN_Channel_Russia6_864_7_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a1e4fabf79c66822c916919e19af2360eab24620e27f22ec8353d6c3081f7e4f09", null ],
      [ "LoRaWAN_Channel_Russia6_864_9_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a1e4fabf79c66822c916919e19af2360eaf7af1673c80985608b61f9892376fbf3", null ],
      [ "LoRaWAN_Channel_Russia6_869_1_Mhz_2", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a1e4fabf79c66822c916919e19af2360ea48f8bf8843a73284edebfe5430ef7c3d", null ]
    ] ],
    [ "TLoRaWAN_Channel_RussiaThree", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a0e1957ae5ea25a73ab3d7b9ec14da2f4", [
      [ "LoRaWAN_Channel_Russia3_868_78_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a0e1957ae5ea25a73ab3d7b9ec14da2f4a011340e3a40ded352df1d70eb98fe63c", null ],
      [ "LoRaWAN_Channel_Russia3_868_95_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a0e1957ae5ea25a73ab3d7b9ec14da2f4a1d63228e040ba12654271d8d3269b1f8", null ],
      [ "LoRaWAN_Channel_Russia3_869_12_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a0e1957ae5ea25a73ab3d7b9ec14da2f4a899521968b79f541ee90858e5e760aa0", null ]
    ] ],
    [ "TLoRaWAN_Channel_RussiaTwo", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a34240b56ebddc94dd97f6d86c1ee4692", [
      [ "LoRaWAN_Channel_Russia2_868_9_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a34240b56ebddc94dd97f6d86c1ee4692a67024fdfc970bc674c7b3fab6e3f7b4b", null ],
      [ "LoRaWAN_Channel_Russia2_868_7_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a34240b56ebddc94dd97f6d86c1ee4692a86cb7263053bd6f4f8b42bb1b3b12e6e", null ],
      [ "LoRaWAN_Channel_Russia2_869_1_Mhz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a34240b56ebddc94dd97f6d86c1ee4692aeed42c10de4e14d7992cd83e2f860824", null ]
    ] ],
    [ "TLoRaWANDataRateRU868", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a45d005360afb213ecdfcc9dfc1cb58bb", [
      [ "LoRaWAN_DataRate_RU868_LoRa_SF12_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a45d005360afb213ecdfcc9dfc1cb58bba7c3e7b4d8ddfab862c824c09128d3341", null ],
      [ "LoRaWAN_DataRate_RU868_LoRa_SF11_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a45d005360afb213ecdfcc9dfc1cb58bba2bcc440b8cf731612ab90411c4b75fa7", null ],
      [ "LoRaWAN_DataRate_RU868_LoRa_SF10_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a45d005360afb213ecdfcc9dfc1cb58bbae78649fd310cf40487e14cbc5c859584", null ],
      [ "LoRaWAN_DataRate_RU868_LoRa_SF9_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a45d005360afb213ecdfcc9dfc1cb58bbac2796fef7822ee7e4856cbd19122b0d5", null ],
      [ "LoRaWAN_DataRate_RU868_LoRa_SF8_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a45d005360afb213ecdfcc9dfc1cb58bba6f209031a5b92191f7336d30da2d696b", null ],
      [ "LoRaWAN_DataRate_RU868_LoRa_SF7_125kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a45d005360afb213ecdfcc9dfc1cb58bba1b4984eea4a6f530c996e09d6ff6a48b", null ],
      [ "LoRaWAN_DataRate_RU868_LoRa_SF7_250kHz", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a45d005360afb213ecdfcc9dfc1cb58bba1aee4ce548525198dac24df109af5909", null ],
      [ "LoRaWAN_DataRate_RU868_LoRa_FSK", "_wi_m_o_d___s_a_p___l_o_r_a_w_a_n___i_ds___r_u868_8h.html#a45d005360afb213ecdfcc9dfc1cb58bba39640c0c7a3b0270e6c16bae3b0671d0", null ]
    ] ]
];